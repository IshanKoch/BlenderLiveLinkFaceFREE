bl_info = { 
"author":"Nick Fisher <nick.fisher@avinium.com>",
"name":"LiveLinkFace Add-On",
"blender":(3,1,0),
"category":"3D View",
"location": "View3D > Sidebar > LiveLinkFace"
}

import os, sys, bpy
from bpy.app.handlers import persistent
from livelinkface.bpy_utils import register_custom_list_operators, unregister_custom_list_operators
from livelinkface.operators import      LiveLinkFacePanel,      ConnectOperator,      LoadCSVOperator,      ExportCSVOperator,      BlendshapeRemapItem,      BLENDSHAPE_OT_remap_action,      LiveLinkFaceRemapPanel,      LiveLinkFaceTargetPanel,      LiveLinkFaceStreamPanel,     LiveLinkFaceLoadCSVPanel,     LiveLinkFaceExportCSVPanel,     LiveLinkFaceFilterPanel,     LiveLinkFaceHeadNeckDriverPanel,     TARGET_BLENDSHAPES,      BLENDSHAPE_UL_remap_list,     OBJECT_OT_add_update_head_drivers

from livelinkface.server import *
from livelinkface.target import *

def armature_filter(self, object):
    return object.type == 'ARMATURE'

def register():
    register_custom_list_operators("ll", "ll_targets", "ll_index")
    bpy.utils.register_class(LiveLinkFacePanel)
    bpy.utils.register_class(ConnectOperator)
    bpy.utils.register_class(LoadCSVOperator)
    

    bpy.types.Scene.ll_is_listening = bpy.props.BoolProperty(name="Server listening", description="Whether the server is currently listening", default=False)
    bpy.types.Scene.ll_host_ip = bpy.props.StringProperty(name="Host IP", description="IP address of the interface on this machine to listen", default="0.0.0.0")
    bpy.types.Scene.ll_host_port = bpy.props.IntProperty(name="Port", description="Port", default=11111)

    bpy.types.Scene.ll_record_stream = bpy.props.BoolProperty(
        name="Record",
        description="Record blendshapes to actions (if false, the viewport is updated in realtime but nothing is saved)",
        default = False
    )

    bpy.types.Scene.ll_filter = bpy.props.BoolProperty(
        name="Filter",
        description="Reduce jitter and smooth blendshapes by applying Kalman filter to the stream and/or CSV.",
        default = True
    )

    bpy.types.Scene.ll_armature = bpy.props.PointerProperty(
        type=bpy.types.Object,
        poll=armature_filter,
        name="Armature",
        description="Armature to drive head/neck bones",
    )

    bpy.types.Scene.ll_head_bone = bpy.props.StringProperty(
        name="Head Bone",
        description="Bone to use for head rotation",
    )

    bpy.types.Scene.ll_head_rotation_order = bpy.props.EnumProperty(
        name="Rotation Order",
        items=[
            ('HeadPitch-HeadYaw-HeadRoll', 'HeadPitch-HeadYaw-HeadRoll', 'HeadPitch-HeadYaw-HeadRoll'),
            ('HeadPitch-HeadRoll-HeadYaw', 'HeadPitch-HeadRoll-HeadYaw', 'HeadPitch-HeadRoll-HeadYaw'),
            ('HeadYaw-HeadRoll-HeadPitch', 'HeadYaw-HeadRoll-HeadPitch', 'HeadYaw-HeadRoll-HeadPitch'),
            ('HeadYaw-HeadPitch-HeadRoll', 'HeadYaw-HeadPitch-HeadRoll', 'HeadYaw-HeadPitch-HeadRoll'),
            ('HeadRoll-HeadPitch-HeadYaw', 'HeadRoll-HeadPitch-HeadYaw', 'HeadRoll-HeadPitch-HeadYaw'),
            ('HeadRoll-HeadYaw-HeadPitch', 'HeadRoll-HeadYaw-HeadPitch', 'HeadRoll-HeadYaw-HeadPitch'),
        ],
        description="XYZ axis mappings for HeadPitch/HeadYaw/HeadRoll",
        default='HeadPitch-HeadYaw-HeadRoll',
    )

    bpy.types.Scene.ll_head_weight = bpy.props.FloatProperty(
        name="Weight",
        description="Weight of head rotation driver",
        min=0.0,
        max=1.0,
        default=1.0,
    )

    bpy.types.Scene.ll_load_csv_use_current_action = bpy.props.BoolProperty(
        name="Use current action/frame",
        description="If true, the current action(s) will be used to load the CSV (and from the current frame)",
        default = False
    )

    bpy.utils.register_class(BlendshapeRemapItem)
    bpy.utils.register_class(BLENDSHAPE_OT_remap_action)
   
    bpy.utils.register_class(LiveLinkFaceStreamPanel)
    bpy.utils.register_class(LiveLinkFaceLoadCSVPanel)
    
    
        
    bpy.utils.register_class(OBJECT_OT_add_update_head_drivers)

    bpy.types.Scene.blendshape_remap = bpy.props.CollectionProperty(type=BlendshapeRemapItem)
    bpy.types.Scene.blendshape_remap_index = bpy.props.IntProperty()
    bpy.app.handlers.load_post.append(initialize_blendshape_remap)

    bpy.app.timers.register(lambda: initialize_blendshape_remap(None), first_interval=0.1)

def unregister():
    bpy.utils.unregister_class(LiveLinkFacePanel)
    bpy.utils.unregister_class(ConnectOperator)
    bpy.utils.unregister_class(LoadCSVOperator)
    
    try:
        bpy.utils.unregister_class(ExportCSVOperator)
    except:
        pass
    
    try:
        unregister_custom_list_operators("ll","ll_targets", "ll_index")
    except:
        pass
    del bpy.types.Scene.ll_is_listening
    del bpy.types.Scene.ll_host_ip
    del bpy.types.Scene.ll_host_port
    del bpy.types.Scene.ll_record_stream

    del bpy.types.Scene.ll_armature
    
    try:
        del bpy.types.Scene.invert_lr_mouth
    except:
        pass
    del bpy.types.Scene.ll_load_csv_use_current_action   
    del bpy.types.Scene.blendshape_remap
    del bpy.types.Scene.blendshape_remap_index
    
    try:
        bpy.utils.unregister_class(LiveLinkFaceRemapPanel)
    except:
        pass
    
    bpy.utils.unregister_class(LiveLinkFaceHeadNeckDriverPanel)   
    bpy.utils.unregister_class(LiveLinkFaceStreamPanel)
    try:
        bpy.utils.unregister_class(LiveLinkFaceExportCSVPanel)    
    except:
        pass
    
    try:
        bpy.utils.unregister_class(LiveLinkFaceLoadCSVPanel)
    except:
        pass
    
    try:
        bpy.utils.unregister_class(LiveLinkFaceFilterPanel)
    except:
        pass
    
    bpy.utils.unregister_class(BLENDSHAPE_OT_remap_action)
    bpy.utils.unregister_class(BLENDSHAPE_UL_remap_list)
    bpy.utils.unregister_class(BlendshapeRemapItem)
    bpy.utils.unregister_class(OBJECT_OT_add_update_head_drivers)

@persistent
def initialize_blendshape_remap(dummy):
    print("Initializing remap")
    if len(bpy.context.scene.blendshape_remap) != len(TARGET_BLENDSHAPES) - 3:
        bpy.context.scene.blendshape_remap.clear()
    else:
        print(f"Found blendshape_remap of length {len(bpy.context.scene.blendshape_remap)}")
    if len(bpy.context.scene.blendshape_remap) == 0:   
        for target in TARGET_BLENDSHAPES[:-3]:
            item = bpy.context.scene.blendshape_remap.add()
            item.source = target[0].lower() + target[1:]
            print(f"Added {target}")

if __name__ == "__main__":
    register()
 



