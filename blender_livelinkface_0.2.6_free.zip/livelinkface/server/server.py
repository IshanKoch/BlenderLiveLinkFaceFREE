import datetime
import bpy
import os
import traceback
import time
import socket
from livelinkface.pylivelinkface import PyLiveLinkFace, FaceBlendShape
from livelinkface.target import LiveLinkTarget
from livelinkface.filters import KalmanFilter

class LiveLinkFaceServer:

    def __init__(
        self,
        target_objects,
        record,
        host,
        udp_port,
        frame = 1,
        blendshape_mapping=None,
        filter=True,
    ):
        self.livelink_start_frame = None
        self.record = record
        self.filter = filter
        self.frame = frame
        self.listening = False
        self.host = host
        self.port = udp_port
        self.targets = []
        
        now = datetime.datetime.now()
        facial_action = bpy.data.actions.new(f"LiveLinkFace FacialRecording {now}")
        head_action = bpy.data.actions.new(f"LiveLinkFace HeadRecording {now}")
        
        for i, target_object in enumerate(target_objects):                   
            target = LiveLinkTarget(
                target_object,
                facial_action=facial_action, 
                head_action=head_action,
                blendshape_mapping=blendshape_mapping,
            )
            self.targets += [target]
        if self.filter:
            self.filters = [
                KalmanFilter(0, 0.5, 0.1, 0.1) for _ in range(len(FaceBlendShape))
            ]
        self.create_socket()
        bpy.app.timers.register(self.read_from_socket)
        print(f"Ready to receive network stream on {self.host}:{self.port}")

    def isListening(self):
        return self.listening

    def listen(self):
        self.listening = True

    def stopListening(self):
        self.listening = False

    def create_socket(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setblocking(False)
        self.sock.bind((self.host, self.port))
        print("Created socket")

    def read_from_socket(self):
        if not self.listening:
            return
        
        interval = 1 / 60

        try:
            data, addr = self.sock.recvfrom(512)
            success, live_link_face = PyLiveLinkFace.decode(data)

            if success:
                if self.livelink_start_frame is None:
                    self.livelink_start_frame = live_link_face._frames

                for t in self.targets:
                    for i in range(len(FaceBlendShape)):
                        val = live_link_face.get_blendshape(FaceBlendShape(i))
                        if self.filter:
                            val = self.filters[i].update(val)
                        if self.record:
                            self.frame = live_link_face._frames - self.livelink_start_frame
                    
                        t.set_frame_value(
                            i, self.frame, val
                        )
            while True:
                self.sock.recvfrom(2048)
            print("Done")
        except socket.error as e:
            pass
        except Exception as e:
            print(traceback.format_exc())
            print(e)
        if self.frame is not None:
            bpy.context.scene.frame_current = self.frame

        return interval

    def close(self):
        print("Closing server")
        self.stopListening()
        try:
            bpy.app.timers.unregister(self.read_from_socket)
        except Exception as e:
            print("Failed to unregister timer")
            print(e)
            pass
        self.sock.close()
        self.livelink_start_frame = None

