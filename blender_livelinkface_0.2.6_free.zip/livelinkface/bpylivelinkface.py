
import bpy 
import importlib
import livelinkface

_instance = None

def has_instance():
    global _instance
    return _instance != None

'''
Create a listener (an instance of LiveLinkFaceServer) on the given IP/port. 
Prefer using this method than constructing an instance directly as this will ensure that any pre-existing connections are closed
'''
def create_instance(
    targets, 
    record=False, 
    filter=True,
    host= "0.0.0.0", 
    port = 11111, 
    start_frame=1,
    blendshape_mapping=None):
    importlib.reload(livelinkface)
    
    global _instance
    if _instance is not None:
        _instance.close()
    _instance = livelinkface.LiveLinkFaceServer(
        targets, 
        record, 
        host, 
        port, 
        blendshape_mapping=blendshape_mapping,
        filter=filter,
        frame=start_frame
    )
    _instance.listen()

def destroy_instance():
    global _instance
    try:
        _instance.stopListening()
        _instance.close()        
    except Exception as e:
        print(e)

    _instance = None

def is_listening():
    global _instance
    return _instance.isListening()

    
