import os, bpy, datetime

from bpy_extras.io_utils import ImportHelper, ExportHelper

from bpy.props import (IntProperty,
                       BoolProperty,
                       StringProperty,
                       CollectionProperty,
                       PointerProperty)

from bpy.types import (Operator,
                       Panel,
                       PropertyGroup,
                       UIList)

import livelinkface.bpylivelinkface as llf
import livelinkface
import traceback

TARGET_BLENDSHAPES = [
    "EyeBlinkLeft", "EyeLookDownLeft", "EyeLookInLeft", "EyeLookOutLeft", "EyeLookUpLeft",
    "EyeSquintLeft", "EyeWideLeft", "EyeBlinkRight", "EyeLookDownRight", "EyeLookInRight",
    "EyeLookOutRight", "EyeLookUpRight", "EyeSquintRight", "EyeWideRight", "JawForward",
    "JawRight", "JawLeft", "JawOpen", "MouthClose", "MouthFunnel", "MouthPucker",
    "MouthRight", "MouthLeft", "MouthSmileLeft", "MouthSmileRight", "MouthFrownLeft",
    "MouthFrownRight", "MouthDimpleLeft", "MouthDimpleRight", "MouthStretchLeft",
    "MouthStretchRight", "MouthRollLower", "MouthRollUpper", "MouthShrugLower",
    "MouthShrugUpper", "MouthPressLeft", "MouthPressRight", "MouthLowerDownLeft",
    "MouthLowerDownRight", "MouthUpperUpLeft", "MouthUpperUpRight", "BrowDownLeft",
    "BrowDownRight", "BrowInnerUp", "BrowOuterUpLeft", "BrowOuterUpRight", "CheekPuff",
    "CheekSquintLeft", "CheekSquintRight", "NoseSneerLeft", "NoseSneerRight", "TongueOut",
    "HeadYaw", "HeadPitch", "HeadRoll"
]

class BlendshapeRemapItem(PropertyGroup):
    source: StringProperty(name="Source Blendshape")

class BLENDSHAPE_UL_remap_list(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text=TARGET_BLENDSHAPES[index])
            row.prop(item, "source", text="", emboss=False)

class BLENDSHAPE_OT_remap_action(Operator):
    bl_idname = "blendshape.remap_action"
    bl_label = "Blendshape Remap Actions"
    bl_options = {'REGISTER', 'UNDO'}

    action: bpy.props.EnumProperty(
        items=(
            ('RESET', "Reset", ""),
            ('SWAP_MOUTH', "Swap Mouth", ""),
            ('UPPERCASE', "Uppercase", ""),
        )
    )

    def execute(self, context):
        if self.action == 'RESET':
            for i, item in enumerate(context.scene.blendshape_remap):
                item.source = TARGET_BLENDSHAPES[i][0].lower() + TARGET_BLENDSHAPES[i][1:]
        elif self.action == 'SWAP_MOUTH':
            mouth_left_index = TARGET_BLENDSHAPES.index("MouthLeft")
            mouth_right_index = TARGET_BLENDSHAPES.index("MouthRight")
            mouth_left = context.scene.blendshape_remap[mouth_left_index].source
            mouth_right = context.scene.blendshape_remap[mouth_right_index].source
            context.scene.blendshape_remap[mouth_left_index].source = mouth_right
            context.scene.blendshape_remap[mouth_right_index].source = mouth_left
        elif self.action == 'UPPERCASE':
            for i, item in enumerate(context.scene.blendshape_remap):
                item.source = TARGET_BLENDSHAPES[i]
        return {'FINISHED'}

class OBJECT_OT_add_update_head_drivers(Operator):
    bl_idname = "object.add_update_head_drivers"
    bl_label = "Add/Update Bone Driver"
    bl_description = "Add or update drivers for head bone rotation"

    def execute(self, context):
        scene = context.scene
        armature = scene.ll_armature

        head_bone_name = scene.ll_head_bone
        weight = scene.ll_head_weight

        if not armature or not head_bone_name:
            self.report({'ERROR'}, "Armature and head bone must be selected")
            return {'CANCELLED'}

        head_bone = armature.pose.bones.get(head_bone_name)
        if not head_bone:
            self.report({'ERROR'}, f"Bone '{head_bone_name}' not found in armature")
            return {'CANCELLED'}

        head_bone.rotation_mode = 'XYZ'
        order = bpy.context.scene.ll_head_rotation_order.split("-")
        driver_mappings = [
            ('rotation_euler', 0, order[0]),
            ('rotation_euler', 1, order[1]),
            ('rotation_euler', 2, order[2])
        ]

        if armature.animation_data is None:
            armature.animation_data_create()

        for data_path, array_index, prop_name in driver_mappings:
            fcurve = armature.animation_data.drivers.find(f'pose.bones["{head_bone_name}"].{data_path}', index=array_index)
            if not fcurve:
                fcurve = armature.animation_data.drivers.new(f'pose.bones["{head_bone_name}"].{data_path}', index=array_index)
            
            driver = fcurve.driver
            
            for var in driver.variables:
                driver.variables.remove(var)

            var = driver.variables.new()
            var.name = 'var'
            var.type = 'SINGLE_PROP'
            var.targets[0].id_type = 'OBJECT'
            var.targets[0].id = scene.ll_targets[0].obj
            var.targets[0].data_path = f'["{prop_name}"]'

            driver.type = "SCRIPTED"
            driver.expression = f"var * {weight}"
            print(f"Set expression to {driver.expression}")

        self.report({'INFO'}, "Head drivers added/updated successfully")
        return {'FINISHED'}

class LiveLinkFaceHeadNeckDriverPanel(Panel):
    bl_idname = "VIEW3D_PT_live_link_face_head_neck_driver"
    bl_parent_id = "VIEW3D_PT_live_link_face"
    bl_label = "Head/Neck Bone Driver"
    bl_category = "LiveLinkFace"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row()
        row.prop(context.scene, "ll_armature")

        row = layout.row()
        if scene.ll_armature:
            row.prop_search(scene, "ll_head_bone", scene.ll_armature.data, "bones", text="Head Bone")

        row = layout.row()
        row.prop(scene, "ll_head_rotation_order")

        row = layout.row()
        row.prop(scene, "ll_head_weight", slider=True)

        row = layout.row()
        row.operator("object.add_update_head_drivers")



class LiveLinkFaceRemapPanel(Panel):
    bl_idname = "VIEW3D_PT_live_link_face_remap"
    bl_parent_id = "VIEW3D_PT_live_link_face"
    bl_label = "Blendshape Remapping"
    bl_category = "LiveLinkFace"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        row = layout.row()
        row.label(text="Target Blendshape")
        row.label(text="Source Blendshape")
        row = layout.row()
        row.template_list("BLENDSHAPE_UL_remap_list", "", scene, "blendshape_remap", 
                          scene, "blendshape_remap_index", rows=10)
        layout.operator("blendshape.remap_action", text="Uppercase").action = 'UPPERCASE'
        layout.operator("blendshape.remap_action", text="Swap MouthLeft/MouthRight").action = 'SWAP_MOUTH'
        layout.operator("blendshape.remap_action", text="Reset to Default").action = 'RESET'

class LiveLinkFaceTargetPanel(Panel):
    bl_idname = "VIEW3D_PT_live_link_face_target"
    bl_parent_id = "VIEW3D_PT_live_link_face"
    bl_label = "Target"
    bl_category = "LiveLinkFace"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"HEADER_LAYOUT_EXPAND"}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rows = 2
        row = self.layout.row()
        row.template_list("CUSTOM_UL_items", "", bpy.context.scene, "ll_targets", bpy.context.scene, "ll_index", rows=rows)
        col = row.column(align=True)
        col.operator("ll_custom.list_action", icon='ADD', text="").action = 'ADD'
        col.operator("ll_custom.list_action", icon='REMOVE', text="").action = 'REMOVE'

class LiveLinkFaceFilterPanel(Panel):
    bl_idname = "VIEW3D_PT_live_link_face_filter"
    bl_label = "Filtering"
    bl_category = "LiveLinkFace"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rows = 2
        row = self.layout.row()
        row.prop(context.scene, "ll_filter", text="Filter")

class LiveLinkFaceStreamPanel(Panel):
    bl_idname = "VIEW3D_PT_live_link_face_stream"
    bl_label = "Stream"
    bl_category = "LiveLinkFace"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        rows = 2
        row = self.layout.row()
        row.prop(context.scene, "ll_host_ip") 
        row.prop(context.scene, "ll_host_port")      
        row = self.layout.row()
        
        row.operator("scene.connect_operator", text="Disconnect" if llf.has_instance() and llf.is_listening() else "Connect")

class LiveLinkFaceExportCSVPanel(Panel):
    bl_idname = "VIEW3D_PT_live_link_face_export_csv"
    bl_label = "Export to CSV"
    bl_category = "LiveLinkFace"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        row = self.layout.row()
        export_csv = row.operator("scene.export_csv_operator")

class LiveLinkFaceLoadCSVPanel(Panel):
    bl_idname = "VIEW3D_PT_live_link_face_load_csv"
    bl_label = "Load from CSV"
    bl_category = "LiveLinkFace"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        row = self.layout.row()
        
        load_csv = row.operator("scene.load_csv_operator")

def checkPrereqs(self, context):
    if len(context.scene.ll_targets) == 0:
        self.report({"ERROR"}, "No target object selected")
    elif context.scene.ll_host_ip is None or len(context.scene.ll_host_ip) == 0:
        self.report({"ERROR"}, "No IP address set")
    elif context.scene.ll_host_port is None:
        self.report({"ERROR"}, "No port set")
    else:
        return True
    return False

class LoadCSVOperator(Operator, ImportHelper):
    bl_idname = "scene.load_csv_operator"
    bl_label = "Load from CSV"
        
    filename_ext = ".csv"
    filter_glob: bpy.props.StringProperty(options={'HIDDEN'}, default='*.csv',maxlen=255)

    def execute(self, context):
        if checkPrereqs(self, context):
            try:
                
                target_objects = [t.obj for t in context.scene.ll_targets]
                blendshape_mapping = {}
                for key, value in zip(TARGET_BLENDSHAPES[:-3], context.scene.blendshape_remap):
                    blendshape_mapping[key] = value.source
                
                use_existing_action = context.scene.ll_load_csv_use_current_action
                start_frame = context.scene.frame_current if use_existing_action else 1

                print(f"Loading CSV from filepath {self.filepath}")
                
                livelinkface.target.LiveLinkTarget.from_csv(
                    target_objects, 
                    self.filepath, 
                    use_existing_action=use_existing_action, 
                    blendshape_mapping=blendshape_mapping,
                    start_frame=start_frame
                )
                self.report({"INFO"}, "Loaded")
                return {'FINISHED'}
            except Exception as e:
                print(e)
                print(traceback.format_exc())
                self.report({"ERROR"}, f"Error loading from CSV : {self.filepath}")
        return {'CANCELLED'}

class ExportCSVOperator(Operator, ExportHelper):
    bl_idname = "scene.export_csv_operator"
    bl_label = "Export to CSV"
        
    filename_ext = ".csv"
    filter_glob: bpy.props.StringProperty(options={'HIDDEN'}, default='*.csv',maxlen=255)

    def execute(self, context):
        try:
            blendshape_mapping = {}
            for key, value in zip(TARGET_BLENDSHAPES, context.scene.blendshape_remap):
                blendshape_mapping[key] = value.source


            facial_action = bpy.context.object.data.shape_keys.animation_data.action
            head_action = bpy.context.object.animation_data.action
            
            if facial_action is None:
                raise Exception("Facial action does not exist")
            
            if head_action is None:
                raise Exception("Head action does not exist")
            
            print(f"Exporting with facial action {facial_action} and head action {head_action}")
            
            livelinkface.target.LiveLinkTarget.to_csv(
                self.filepath,
                facial_action=facial_action,
                head_action=head_action,
                blendshape_mapping=blendshape_mapping
            )
            self.report({"INFO"}, "Export complete")
            return {'FINISHED'}
        except Exception as e:
            print(e)
            print(traceback.format_exc())
            self.report({"ERROR"}, f"Error exporting to CSV : {self.filepath}")
        return {'CANCELLED'}
        
class ConnectOperator(bpy.types.Operator):
    bl_idname = "scene.connect_operator"
    bl_label = "connectbutton"

    def execute(self, context):
        if llf.has_instance():
            llf.destroy_instance()
            context.scene.ll_is_listening = False
            self.report({"INFO"}, "Disconnected")
            return {'FINISHED'}
        else:
            if checkPrereqs(self, context):
                try:
                    target_objects = [t.obj for t in context.scene.ll_targets]
                    now = datetime.datetime.now()

                    stream = context.scene.ll_record_stream
                    filter = context.scene.ll_filter
                    host_ip = context.scene.ll_host_ip
                    host_port = context.scene.ll_host_port
                    blendshape_mapping = {}
                    for key, value in zip(TARGET_BLENDSHAPES, context.scene.blendshape_remap):
                        blendshape_mapping[key] = value.source
                    llf.create_instance(
                        target_objects, 
                        record=stream, 
                        host=host_ip, 
                        port=host_port, 
                        blendshape_mapping=blendshape_mapping,
                        filter=filter)
                    self.report({"INFO"}, "Started")
                except Exception as e:
                    print(e)
                    try:
                        llf.destroy_instance()
                    except Exception as e:
                        print(e)
                        self.report({"ERROR"}, f"Error connecting : {e}")
                        return {"ERROR"}
                    self.report({"ERROR"}, f"Error connecting : {e}")
                return {'FINISHED'}
            return {"CANCELLED"}

class LiveLinkFacePanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_live_link_face"
    bl_label = "LiveLinkFace"
    bl_category = "LiveLinkFace"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"HEADER_LAYOUT_EXPAND"}

    def draw(self, context):
        box = self.layout.box()
        box.label(text="Target")                
        rows = 2
        row = box.row()
        row.template_list("CUSTOM_UL_items", "", bpy.context.scene, "ll_targets", bpy.context.scene, "ll_index", rows=rows)
        col = row.column(align=True)
        col.operator("ll_custom.list_action", icon='ADD', text="").action = 'ADD'
        col.operator("ll_custom.list_action", icon='REMOVE', text="").action = 'REMOVE'


